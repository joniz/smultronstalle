const db = require('./db-implementations/SQL-inplementation.js');

module.exports = db;